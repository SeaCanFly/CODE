/*
CreateProcess.cpp
���α׷� ���� : ���� ���μ����� ����
*/

#include <stdio.h>
#include <tchar.h>
#include <windows.h>


#define DIR_LEN MAX_PATH+1

int _tmain( int argc,TCHAR* argv[ ] )
{
	STARTUPINFO si = { 0, };
	PROCESS_INFORMATION pi;

	si.cb = sizeof( si );
	si.dwFlags = STARTF_USEPOSITION | STARTF_USESIZE;
	si.dwX = 100;
	si.dwY = 200;
	si.dwXSize = 300;
	si.dwYSize = 200;
	si.lpTitle = _T( "I am a boy!" );

	TCHAR input1;
	TCHAR input2;
	TCHAR input3;

	_tscanf_s( _T( "%c" ),&input1 );
	_tscanf_s( _T( "%c" ),&input2 );
	_tscanf_s( _T( "%c" ),&input3 );

	TCHAR mycommand[ 256 ] = _T( "AdderProcess.exe " );
	_tcscat_s( mycommand,&input1 );
	_tcscat_s( mycommand,_T( " " ) );
	_tcscat_s( mycommand,&input2 );
	_tcscat_s( mycommand,_T( " " ) );
	_tcscat_s( mycommand,&input3 );

	//TCHAR command[ ] = _T( "AdderProcess.exe 10 20 30" );
	TCHAR cDir[ DIR_LEN ];
	BOOL state;

	GetCurrentDirectory( DIR_LEN,cDir );	//���� ���丮 Ȯ��.
	_fputts( cDir,stdout );
	_fputts( _T( "\n" ),stdout );

	SetCurrentDirectory( _T( "C:\\" ) );

	GetCurrentDirectory( DIR_LEN,cDir );	//���� ���丮 Ȯ��.
	_fputts( cDir,stdout );
	_fputts( _T( "\n" ),stdout );


	state = CreateProcess( NULL,     // ���μ��� ����.
						   mycommand,
						   NULL,
						   NULL,
						   TRUE,
						   CREATE_NEW_CONSOLE,
						   NULL,  
						   NULL,
						   &si,
						   &pi
	);  //CreateProcess

	if( state != 0 )
		_fputts( _T( "Create OK! \n" ),stdout );
	else
		_fputts( _T( "Create Error! \n" ),stdout );

	system( "pause" );

	return 0;
}