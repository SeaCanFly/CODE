#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#pragma comment(lib,"ws2_32")
#include<WinSock2.h>
#include<iostream>
#include<tchar.h>
#include<stdlib.h>

#define TestAddress "localhost"		//ISP�� �����Ǵ� �̸��� �����Ǿ� ���� ������ �ȵ�

class Converting
{
private:
	WSADATA Wsadata;
public:
	IN_ADDR Addr;
	Converting();
	~Converting();
	VOID Error_Display(TCHAR *Msg);										//Socket Error
	BOOL GetIpAddr(CHAR *Name, IN_ADDR *Addr);							//Domain Name -> IPv4 Address
	BOOL GetDomainName(CHAR *Name, INT NameLen);						//IPv4 Adress-> Domain Name
	BOOL ErrorCheck();
};

Converting::Converting()
{
	if (WSAStartup(MAKEWORD(2, 2), &Wsadata) != 0)
		return;
}
Converting::~Converting()
{
	WSACleanup();
}
VOID Converting::Error_Display(TCHAR *Msg)
{
	LPVOID lpMsgBuf;
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL, WSAGetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR)&lpMsgBuf, 0, NULL);
	std::cout << Msg << (TCHAR *)lpMsgBuf;
	LocalFree(lpMsgBuf);
}


BOOL Converting::GetIpAddr(CHAR *Name, IN_ADDR *Addr)
{
	HOSTENT *Ptr = gethostbyname(Name);
	if (Ptr == NULL)
	{
		Error_Display(_T("Gethostbyname()"));
		return FALSE;
	}

	if (Ptr->h_addrtype != AF_INET)
		return FALSE;

	memcpy(Addr, Ptr->h_addr, Ptr->h_length);
	return TRUE;
}

BOOL Converting::GetDomainName(CHAR *Name, INT NameLen)
{
	HOSTENT *Ptr = gethostbyaddr((CHAR *)&Addr, sizeof(Addr), AF_INET);

	if (Ptr == NULL)
	{
		this->Error_Display(_T("Gethostbyaddr()"));
		return FALSE;
	}

	if (Ptr->h_addrtype != AF_INET)
		return FALSE;
	strncpy(Name, Ptr->h_name, NameLen);
	return TRUE;
}

BOOL Converting::ErrorCheck()
{
	if (GetIpAddr(TestAddress, &Addr))
		return TRUE;
	return FALSE;
}

INT _tmain(INT argc, TCHAR *argv[])
{
	Converting Convert;
	

	//Domain Name -> IP Address
	
	if (Convert.ErrorCheck())
	{
		//if it is Success, Display the result
		std::cout << "IP Address(After Converting,Hex) = 0x"<<std::hex<<(UINT)inet_ntoa(Convert.Addr) << std::endl;
		std::cout << "IP Address(After Converting) = "<<inet_ntoa(Convert.Addr) << std::endl;

		//IP Address -> Domain Name
		CHAR Name[256];
		if (Convert.GetDomainName(Name, sizeof(Name)))
		{
			std::cout << "Domain Name(Re-Converting) =" << Name << std::endl;
		}
	}
	getchar();
	return 0;
}